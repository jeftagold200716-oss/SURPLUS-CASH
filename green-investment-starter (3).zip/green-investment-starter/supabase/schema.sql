-- Run this file in Supabase SQL Editor.
-- Supabase Auth handles password hashing and sessions; do not store passwords in profiles.

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text unique,
  invite_code text,
  balance_xaf bigint not null default 0 check (balance_xaf >= 0),
  last_bonus_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

drop policy if exists "Users can read their own profile" on public.profiles;
create policy "Users can read their own profile"
on public.profiles for select to authenticated
using (auth.uid() = id);

-- No client-side update policy is provided: users must not be able to edit their own balance.

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, full_name, phone, invite_code)
  values (
    new.id,
    new.raw_user_meta_data ->> 'full_name',
    new.phone,
    nullif(new.raw_user_meta_data ->> 'invite_code', '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Atomic, server-side daily reward. A user cannot claim twice within 24 hours.
create or replace function public.claim_daily_bonus()
returns json
language plpgsql
security definer
set search_path = ''
as $$
declare
  updated_balance bigint;
begin
  if auth.uid() is null then
    raise exception 'You must be logged in to claim the bonus.';
  end if;

  update public.profiles
  set balance_xaf = balance_xaf + 200,
      last_bonus_at = now()
  where id = auth.uid()
    and (last_bonus_at is null or last_bonus_at <= now() - interval '24 hours')
  returning balance_xaf into updated_balance;

  if updated_balance is null then
    raise exception 'Your daily bonus has already been claimed. Please try again after 24 hours.';
  end if;

  return json_build_object('balance_xaf', updated_balance);
end;
$$;

revoke all on function public.claim_daily_bonus() from public;
grant execute on function public.claim_daily_bonus() to authenticated;
