"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

type Profile = { full_name: string | null; balance_xaf: number | null };
type Section = "home" | "products" | "team" | "my-products" | "settings";

export default function Dashboard() {
  const router = useRouter();
  const [profile, setProfile] = useState<Profile>({full_name:"",balance_xaf:0});
  const [section, setSection] = useState<Section>("home");
  const [loading, setLoading] = useState(true);
  const [claiming, setClaiming] = useState(false);
  const [message, setMessage] = useState("");
  const [canClaim, setCanClaim] = useState(false);

  useEffect(() => {
    if (!supabase) { setLoading(false); return; }
    let active = true;
    async function load() {
      const { data: { user } } = await supabase!.auth.getUser();
      if (!user) { router.replace("/"); return; }
      const { data, error } = await supabase!.from("profiles")
        .select("full_name,balance_xaf,last_bonus_at").eq("id", user.id).single();
      if (!active) return;
      if (!error && data) {
        setProfile({full_name:data.full_name,balance_xaf:Number(data.balance_xaf ?? 0)});
        const last = data.last_bonus_at ? new Date(data.last_bonus_at).getTime() : 0;
        setCanClaim(Date.now() - last >= 24*60*60*1000);
      } else setMessage("Your profile is not ready yet. Check the Supabase setup guide.");
      setLoading(false);
    }
    load();
    return () => { active = false; };
  }, [router]);

  async function claimBonus() {
    if (!supabase || claiming) return;
    setClaiming(true); setMessage("");
    const { data, error } = await supabase.rpc("claim_daily_bonus");
    if (error) setMessage(error.message);
    else {
      setProfile(p => ({...p, balance_xaf:Number(data?.balance_xaf ?? p.balance_xaf + 200)}));
      setCanClaim(false);
      setMessage("Your daily bonus of 200 XAF has been added.");
    }
    setClaiming(false);
  }
  async function logout() {
    if (supabase) await supabase.auth.signOut();
    router.replace("/");
  }

  const nav: {id:Section; label:string; icon:string}[] = [
    {id:"home",label:"Home",icon:"⌂"},{id:"products",label:"Products",icon:"▦"},
    {id:"team",label:"Team",icon:"♧"},{id:"my-products",label:"My products",icon:"◈"},
    {id:"settings",label:"Settings",icon:"⚙"}
  ];
  if (loading) return <main className="loading-screen">Loading your dashboard…</main>;

  return (
    <main className="dashboard-shell">
      <div className="ambient"><i/><i/><i/><i/><i/><i/><i/></div>
      <header className="topbar glass">
        <div className="brand-small">G<span>V</span> <b>GreenVest</b></div>
        <button className="logout" onClick={logout}>Log out ↗</button>
      </header>
      <div className="dashboard-wrap">
        <div className="welcome-row"><div><p className="eyebrow">YOUR PERSONAL SPACE</p><h1>Hello, {profile.full_name || "Investor"} 👋</h1><p className="muted">Welcome back to your dashboard.</p></div><div className="status-pill"><i/> Account</div></div>
        {section === "home" ? <>
          <section className="balance-card">
            <div className="balance-top"><span>ACCOUNT BALANCE</span><span className="balance-leaf">✦</span></div>
            <div className="balance-amount">{profile.balance_xaf.toLocaleString("en-US")} <small>XAF</small></div>
            <div className="money-actions"><button onClick={()=>setMessage("Deposit options will be added in the next stage.")}>＋ Deposit</button><button onClick={()=>setMessage("Withdrawal options will be added in the next stage.")}>↗ Withdraw</button></div>
          </section>
          <section className="bonus-card">
            <div><span className="bonus-icon">🎁</span><div><h2>Daily bonus</h2><p>Come back every 24 hours to claim your reward.</p></div></div>
            <div className="bonus-bottom"><strong>+200 <small>XAF</small></strong><button disabled={!canClaim || claiming} onClick={claimBonus}>{claiming ? "Claiming…" : canClaim ? "Claim bonus" : "Already claimed"}</button></div>
          </section>
          {message && <p className="notice dashboard-notice" role="status">{message}</p>}
          <section className="terms glass"><h3>Important information</h3><p>Terms and conditions will be published here. Please review all platform rules before using any investment service.</p><p className="developer-note">Developed with care · GreenVest</p></section>
          <section className="quick-grid">
            {nav.filter(n=>n.id!=="home").map(item=><button className="quick-card glass" key={item.id} onClick={()=>setSection(item.id)}><span>{item.icon}</span><b>{item.label}</b><small>Explore {item.label.toLowerCase()} →</small></button>)}
          </section>
        </> : <section className="placeholder glass"><div className="placeholder-icon">{nav.find(n=>n.id===section)?.icon}</div><p className="eyebrow">{section.replace("-"," ")}</p><h2>{nav.find(n=>n.id===section)?.label}</h2><p className="muted">This section is reserved for the features you will describe next.</p><button className="primary-btn" onClick={()=>setSection("home")}>Back to home</button></section>}
      </div>
      <footer className="footer"><div className="brand-small">G<span>V</span> <b>GreenVest</b></div><p>Manage your account with clarity and confidence.</p><small>© {new Date().getFullYear()} GreenVest · All rights reserved.</small></footer>
      <nav className="bottom-nav">{nav.map(item=><button key={item.id} className={section===item.id?"active":""} onClick={()=>setSection(item.id)}><span>{item.icon}</span>{item.label}</button>)}</nav>
    </main>
  );
}
