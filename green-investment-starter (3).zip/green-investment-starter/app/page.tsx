"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { supabase } from "@/lib/supabase";

const cleanCameroonPhone = (raw: string) => {
  let value = raw.replace(/[^\d+]/g, "");
  if (value.startsWith("00237")) value = "+" + value.slice(2);
  if (value.startsWith("237")) value = "+" + value;
  if (/^[62]\d{8}$/.test(value)) value = "+237" + value;
  return value;
};
const validCameroonPhone = (value: string) => /^\+237[26]\d{8}$/.test(value);

export default function EntryPage() {
  const router = useRouter();
  const [mode, setMode] = useState<"register" | "login">("register");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [invite, setInvite] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");

  useEffect(() => {
    if (!supabase) return;
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) router.replace("/dashboard");
    });
  }, [router]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setNotice("");
    if (!supabase) {
      setNotice("Connect your Supabase project first. Add the URL and anon key to .env.local.");
      return;
    }
    const normalized = cleanCameroonPhone(phone);
    if (!validCameroonPhone(normalized)) {
      setNotice("Enter a valid Cameroon number, for example 6XXXXXXXX or +2376XXXXXXXX.");
      return;
    }
    if (password.length < 6) {
      setNotice("Your password must contain at least 6 characters.");
      return;
    }
    if (mode === "register" && !name.trim()) {
      setNotice("Please enter your full name.");
      return;
    }
    setBusy(true);
    try {
      if (mode === "register") {
        const { error } = await supabase.auth.signUp({
          phone: normalized,
          password,
          options: { data: { full_name: name.trim(), invite_code: invite.trim() } }
        });
        if (error) throw error;
        setNotice("Registration submitted. Check your phone for the Supabase verification code, then verify your number in Supabase before logging in. SMS delivery must be configured in Supabase.");
      } else {
        const { error } = await supabase.auth.signInWithPassword({ phone: normalized, password });
        if (error) throw error;
        router.replace("/dashboard");
      }
    } catch (err) {
      setNotice(err instanceof Error ? err.message : "Something went wrong. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  const whatsapp = (process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "2376XXXXXXXX").replace(/\D/g, "");
  const helpText = encodeURIComponent("Hello, I need help recovering access to my account.");
  return (
    <main className="auth-shell">
      <div className="ambient"><i/><i/><i/><i/><i/><i/><i/></div>
      <section className="auth-card glass">
        <div className="brand-mark">G<span>V</span></div>
        <p className="eyebrow">WELCOME TO</p>
        <h1>GreenVest</h1>
        <p className="muted">A simpler way to manage your account.</p>
        <div className="switcher">
          <button className={mode === "register" ? "selected" : ""} onClick={() => {setMode("register");setNotice("");}}>Create account</button>
          <button className={mode === "login" ? "selected" : ""} onClick={() => {setMode("login");setNotice("");}}>Login</button>
        </div>
        <form onSubmit={submit}>
          {mode === "register" && <label>Full name<input value={name} onChange={e=>setName(e.target.value)} placeholder="Enter your full name" autoComplete="name" required /></label>}
          <label>Cameroon phone number<div className="phone-input"><span>🇨🇲 +237</span><input value={phone} onChange={e=>setPhone(e.target.value)} placeholder="6XXXXXXXX" autoComplete="tel" required /></div></label>
          <label>Password<input type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="At least 6 characters" minLength={6} autoComplete={mode === "register" ? "new-password" : "current-password"} required /></label>
          {mode === "register" && <label>Invite code <span className="optional">(optional)</span><input value={invite} onChange={e=>setInvite(e.target.value)} placeholder="Enter invite code" /></label>}
          <button className="primary-btn" disabled={busy}>{busy ? "Please wait..." : mode === "register" ? "Create account" : "Login securely"}</button>
        </form>
        <a className="forgot" href={`https://wa.me/${whatsapp}?text=${helpText}`} target="_blank" rel="noreferrer">Forgot password? Contact support on WhatsApp</a>
        {notice && <p className="notice" role="status">{notice}</p>}
        <p className="fine-print">By continuing, you agree to the platform terms and conditions.</p>
      </section>
      <p className="copyright">© {new Date().getFullYear()} GreenVest. All rights reserved.</p>
    </main>
  );
}
