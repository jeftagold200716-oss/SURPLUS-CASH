# GreenVest starter

A first-stage Next.js + Supabase starter for the registration/login flow and dashboard UI.

## Included
- Registration and login using Supabase phone authentication
- Cameroon phone-number normalization and validation (`+237` followed by 9 digits, starting with 2 or 6)
- Password minimum of 6 characters
- Optional invite-code field stored as signup metadata
- WhatsApp forgot-password link (configure your support number)
- Dashboard with XAF balance, Deposit/Withdraw placeholders, 200 XAF daily bonus
- Daily bonus credited by an atomic Supabase database function, limited to once per 24 hours
- Home, Products, Team, My Products and Settings navigation placeholders
- Responsive green animated background and glowing particles

## 1. Create the Supabase project
1. Create a project at https://supabase.com.
2. In **Authentication > Providers > Phone**, enable phone authentication.
3. Configure an SMS provider in Supabase. Phone sign-up normally requires OTP verification; the app shows a message explaining this.
4. Open **SQL Editor**, paste `supabase/schema.sql`, and run it.
5. In **Project Settings > API**, copy the Project URL and anon/public key.

## 2. Run locally
1. Install Node.js (LTS).
2. Extract this folder and open it in VS Code.
3. Copy `.env.example` to `.env.local`.
4. Fill in:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `NEXT_PUBLIC_WHATSAPP_NUMBER` (digits only, e.g. `2376XXXXXXXX`)
5. In a terminal run:

```bash
npm install
npm run dev
```

6. Open http://localhost:3000.

## 3. Deploy with GitHub and Vercel
1. Create a GitHub repository and upload this project.
2. In Vercel, import that GitHub repository.
3. Add the same three environment variables in Vercel **Project Settings > Environment Variables**.
4. Deploy.

## Important notes before real-money use
- Deposit and withdrawal buttons are placeholders only. No payment provider is connected.
- This starter does not implement investment products, profit calculations, referrals, or admin tools.
- The daily bonus is a promotional account credit, not an investment return. It is protected by a server-side database function.
- A real-money investment service may require licensing, identity checks, consumer disclosures, AML controls, audited accounting, secure payment integration and legal review in Cameroon. Do not collect customer funds until those requirements and the business model have been reviewed.
- Never put the Supabase service-role key in browser code or in a `NEXT_PUBLIC_` variable.
- Supabase phone authentication must be configured for OTP verification. A forgotten password should be recovered through a secure, verified process; WhatsApp support should not ask users to send passwords or OTP codes.
